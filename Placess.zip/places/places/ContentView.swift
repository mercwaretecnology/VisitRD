//
//  ContentView.swift
//  places
//
//  Created by MercWareTecnology on 21/12/21.
//

import SwiftUI
import MapKit

struct ContentView: View {
   
    //creando lista de valores
    @State private var locations: [Location] = []
    // cordinate
    @State private var coordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 19.43, longitude: -99.13), span: MKCoordinateSpan(latitudeDelta: 50, longitudeDelta: 50))

    var body: some View {
        Map(coordinateRegion: $coordinateRegion, annotationItems: locations){
            locations in
            MapAnnotation(coordinate:CLLocationCoordinate2D(latitude: locations.latitude, longitude:locations.longitude)){
              

                VStack{
                    
                         Text (locations.place)
                        .font(.caption2)
                        .bold()
                                            
                    Image(systemName: "mappin.circle.fill")
                            .font(.title)
                            .foregroundColor(.red)
                    Image(systemName: "arrowtriangle.down.fill")
                            .font(.title)
                            .foregroundColor(.red)
                            .offset(x: 0, y: -20)
                                                           
                }
                
               
                .onTapGesture {
                    
                      withAnimation(.easeInOut) {
                        
                    
                    }
                                                   
                }
            }
        }
            .onAppear(perform: readFile)
    }
    
    private func readFile() {
        if let url = Bundle.main.url(forResource: "places", withExtension: "json"),
            let  data = try? Data(contentsOf: url){
            let  decoder = JSONDecoder()
            if let jsonData = try? decoder.decode(JSONData.self, from: data){
                self.locations = jsonData.locations
            }
            
        }
    }
}

struct JSONData: Decodable {
    let locations:[Location]
}
struct Location: Decodable,Identifiable {
    let id:Int
    let place:String
    let desc: String
    let latitude: Double
    let longitude: Double
    }
    

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
