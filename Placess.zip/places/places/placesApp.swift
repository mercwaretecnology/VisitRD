//
//  placesApp.swift
//  places
//
//  Created by MercWareTecnology on 21/12/21.
//

import SwiftUI

@main
struct placesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
